import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, BookOpen, Code2, LogOut, UserRound } from 'lucide-react';
import { links } from '../../app/route';
import { useAuthStore } from '../auth/authStore';
import { learnerProgressApi } from '../../api/learning/LearnerProgressApi';
import type { ProgressEvent } from '../learning/types';
import './profile.css';

export default function LearnerProfilePage() {
  const user = useAuthStore((s) => s.learnerUser);
  const restore = useAuthStore((s) => s.restoreLearner);
  const logout = useAuthStore((s) => s.learnerLogout);
  const [hld, setHld] = useState<ProgressEvent[]>([]);
  const [lld, setLld] = useState<ProgressEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      const signedIn = await restore();
      if (!active) return;
      if (!signedIn) { window.location.hash = links.userLogin; return; }
      try {
        const [h, l] = await Promise.all([learnerProgressApi.get('hld'), learnerProgressApi.get('lld')]);
        if (active) { setHld(h); setLld(l); }
      } catch (e) { if (active) setError((e as Error).message); }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [restore]);

  const summary = useMemo(() => (events: ProgressEvent[]) => ({
    lessons: new Set(events.filter((e) => e.type === 'lesson_read' || e.type === 'lab_completed' || e.type === 'quiz_passed').map((e) => e.nodeId)).size,
    labs: new Set(events.filter((e) => e.type === 'lab_completed').map((e) => e.nodeId)).size,
    quizzes: new Set(events.filter((e) => e.type === 'quiz_passed').map((e) => e.nodeId)).size,
  }), []);
  const h = summary(hld); const l = summary(lld);
  const signOut = async () => { setBusy(true); try { await logout(); window.location.hash = links.home; } finally { setBusy(false); } };

  if (loading) return <main className="learner-profile-page"><p>Loading your profile…</p></main>;
  if (!user) return null;
  return <main className="learner-profile-page">
    <header className="profile-header"><a href={links.learn}><ArrowLeft size={16}/> Back to learning</a><button onClick={signOut} disabled={busy}><LogOut size={15}/> {busy ? 'Signing out…' : 'Sign out'}</button></header>
    <section className="profile-identity"><div className="profile-avatar"><UserRound size={26}/></div><div><span className="profile-kicker">LEARNER ACCOUNT</span><h1>{user.name}</h1><p>{user.email}</p></div></section>
    <section className="profile-section"><div className="profile-section-heading"><BookOpen/><div><h2>Learning progress</h2><p>Your progress synced to your account</p></div></div>
      <div className="profile-track-grid"><article><span>HLD · High-Level Design</span><strong>{h.lessons}</strong><small>Lessons with recorded activity</small><div className="profile-metrics"><span>{h.labs} labs completed</span><span>{h.quizzes} quizzes passed</span></div></article><article><span>LLD · Low-Level Design</span><strong>{l.lessons}</strong><small>Lessons with recorded activity</small><div className="profile-metrics"><span>{l.labs} labs completed</span><span>{l.quizzes} quizzes passed</span></div></article></div>
      {error && <p className="profile-error" role="alert">{error}</p>}
    </section>
    <section className="profile-section profile-practice"><div className="profile-section-heading"><Code2/><div><h2>HLD practice · System design questions</h2><p>Question solving history will appear here, connected to the existing question catalogue.</p></div></div><div className="profile-coming"><strong>Question progress is being connected</strong><p>Started, in-progress, evaluator-verified and manually marked solved states will be tracked separately. Reference topics and follow-up questions will remain linked to each catalogue question.</p><a href={links.studio}>Open Architecture Studio <span>→</span></a></div></section>
  </main>;
}
